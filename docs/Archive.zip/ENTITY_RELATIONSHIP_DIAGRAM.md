# FLEETIN — Entity Relationship Diagram

**Phase 2 analysis. Proposed, not implemented. No Prisma models created.**

Every relationship is annotated with the evidence that supports it. Anything not supported by code is marked **⚠️ DD-nn** and appears in `DOMAIN_DECISIONS.md` — it is not drawn as fact.

---

## 1. Full operational map

```mermaid
erDiagram
    SHIPPER   ||--o{ CONTACT      : "primary + operational"
    SHIPPER   ||--o{ DOCUMENT     : owns
    SHIPPER   ||--o{ SHIPMENT     : "orders (customer.id)"

    PARTNER   ||--o{ CONTACT      : "dispatchers"
    PARTNER   ||--o{ DOCUMENT     : owns
    PARTNER   ||--o{ VEHICLE      : "owns fleet"
    PARTNER   ||--o{ DRIVER       : employs
    PARTNER   ||--o{ PRICING_TIER : "quotes route x vehicleType"
    PARTNER   ||--o{ SHIPMENT     : "hauls (transporter.id)"

    VEHICLE   ||--o| DRIVER       : "assigned 0..1 - 0..1"
    VEHICLE   ||--o{ DOCUMENT     : "insurance, registration"
    DRIVER    ||--o{ DOCUMENT     : "licence, national id"
    DRIVER    ||--o{ SHIPMENT     : drives

    LOCATION  ||--o{ SHIPMENT     : "pickup"
    LOCATION  ||--o{ SHIPMENT     : "delivery"
    LOCATION  ||--o{ EMPTY_RETURN : "return yard (locationId)"

    SHIPMENT  ||--o{ SHIPMENT_EVENT  : "stage timeline"
    SHIPMENT  ||--o{ SHIPMENT_CHARGE : "base freight + accessorials"
    SHIPMENT  ||--o{ DELAY_ATTRIBUTION : "stored, never inferred"
    SHIPMENT  ||--o{ DOCUMENT        : "POD, required docs"
    SHIPMENT  ||--o| CONTAINER       : "containerized only"

    CONTAINER ||--o{ EMPTY_RETURN : "becomes an empty"

    EMPTY_RETURN ||--o| EMPTY_RETURN_CYCLE : "cycleId"
    EMPTY_RETURN_CYCLE ||--o| SHIPMENT     : "nextFull consumes a pool shipment"

    ONBOARDING ||--o{ ONBOARDING_ACTION  : "pending actions"
    ONBOARDING ||--o{ ONBOARDING_COMMENT : "audit + status changes"

    USER ||--o{ SHIPMENT : "created by"
    USER ||--o{ DOCUMENT : "verified by"
```

---

## 2. Finance integration — soft references only

The existing finance models reference the operational domain through **unconstrained string ids paired with denormalised name snapshots**. There are no foreign keys, and that is deliberate (BR-5.2: an issued invoice must not change when a partner is renamed).

```mermaid
erDiagram
    SHIPPER  ||..o{ INVOICE       : "shipperId (soft) + name snapshot"
    SHIPMENT ||..o{ INVOICE       : "missionIds Json array (M:N)"
    PARTNER  ||..o{ PAYMENT_ORDER : "transporterId (soft) + name snapshot"
    SHIPMENT ||--|| PAYMENT_ORDER : "missionId (1:1 per PO)"
    SHIPMENT ||..o{ LEDGER_ENTRY  : "missionId (soft, indexed)"

    INVOICE       ||--o{ CREDIT_NOTE        : reduces
    INVOICE       ||--o{ PAYMENT_ALLOCATION : "settled by"
    PAYMENT       ||--o{ PAYMENT_ALLOCATION : "splits across targets"
    PAYMENT_ORDER ||--o{ PAYMENT_ALLOCATION : "settled by"
    DRAWDOWN      ||--o{ PAYMENT_ALLOCATION : "repaid by"

    BANK_ACCOUNT ||--o{ PAYMENT             : from
    BANK_ACCOUNT ||--o{ BANK_STATEMENT_LINE : "imported"
    BANK_ACCOUNT ||--o{ CREDIT_FACILITY     : backs

    CREDIT_FACILITY ||--o{ DRAWDOWN      : "limit, headroom"
    DRAWDOWN     ||--o{ PAYMENT_ORDER    : funds

    RECURRING_EXPENSE_TEMPLATE ||--o{ EXPENSE_ENTRY : generates
```

### Confirmed integration points

| Finance field | Points at | Type | Evidence |
|---|---|---|---|
| `Invoice.shipperId` + `shipperName`/`shipperCompany` | Shipper | soft id + snapshot | `prisma/schema.prisma` |
| `Invoice.missionIds` (**Json array**) | Shipment | **many-to-many** | `Invoice.missionIds: Json` |
| `InvoiceLineItem.missionId` / `.bookingId` | Shipment | one line per mission | `types/finance.ts` |
| `PaymentOrder.transporterId` + names | Partner | soft id + snapshot | schema |
| `PaymentOrder.missionId` | Shipment | **one PO per mission** | schema |
| `PaymentOrder.driverName`, `assignedTruckPlate`, `route` | Driver / Vehicle | **name/plate snapshot only, no id** | schema |
| `LedgerEntry.missionId` (indexed, nullable) | Shipment | denormalised for per-mission P&L without joins | schema |
| `LedgerEntry.counterpartyType` + `counterpartyId` | polymorphic | `SHIPPER\|TRANSPORTER\|BANK\|EMPLOYEE\|VENDOR` | schema |
| `Payment.counterpartyType` + `counterpartyId` | polymorphic | same | schema |
| `PaymentAllocation.targetType` + `targetId` | polymorphic | `INVOICE\|PAYMENT_ORDER\|DRAWDOWN` | schema |
| `ExpenseEntry.paidById` (`emp-01`) | Employee | **table does not exist** | `financeMockData.ts` |
| `*.createdById` / `approvedById` | User | four-eyes audit | schema |

### Two polymorphic patterns must be modelled explicitly

1. `LedgerEntry.{counterpartyType, counterpartyId}` **and** `{sourceType, sourceId}`
2. `PaymentAllocation.{targetType, targetId}`

Prisma cannot express these as relations. They stay as typed string pairs with application-level integrity, exactly as they are now.

### Relationships that are **NOT** evidenced

- `Drawdown.backingInvoiceIds[]` exists in the **TypeScript** type but **not** in the Prisma schema. The `DrawdownExposureStatus` rule (BR-5.12) depends on it. → **DD-09**
- Nothing links `ExpenseEntry.paidById` to any table.
- No link exists between `EmptyReturnRecord` and any finance record — detention/demurrage costs are computed in BI but never posted to the ledger. → **DD-14**

---

## 3. Cardinality register

| Relationship | Cardinality | Optional? | Evidence |
|---|---|---|---|
| Shipper → Shipment | 1 : N | required | `Mission.customer.id` |
| Partner → Shipment | 1 : N | required | `Mission.transporter.id` |
| Partner → Vehicle | 1 : N | required | `PartnerRecord.vehicles[]` |
| Partner → Driver | 1 : N | required | `PartnerRecord.drivers[]` |
| Vehicle ⇄ Driver | **0..1 : 0..1** | both optional | bidirectional `assignedVehicleId` / `assignedDriverId` ⚠️ **DD-06** |
| Shipment → Driver | N : 0..1 | optional | `Mission.driver?` |
| Shipment → Vehicle | N : 0..1 | optional | `Mission.assignedTruck?` |
| Shipment → Location | N : 1 ×2 | required | pickup + delivery, **embedded free text today** |
| Shipment → Container | 1 : 0..1 | containerized only | `containerNumber?` |
| Shipment → ShipmentEvent | 1 : N | — | BI contract |
| Shipment → Charge | 1 : N | — | BI contract |
| Container → EmptyReturn | 1 : N | over time | one record per return trip |
| EmptyReturn → Cycle | N : 0..1 | null until matched | `cycleId` |
| Cycle → Shipment (nextFull) | 1 : 0..1 | optional | `nextFull.shipmentId?` |
| EmptyReturn → Shipment | N : 0..1 | **the only hard FK in that module** | `shipmentId?` |
| Chain → Cycle | **derived** | — | `GROUP BY chainId` |
| Invoice ⇄ Shipment | **M : N** | — | `missionIds` Json array |
| PaymentOrder → Shipment | 1 : 1 | required | `missionId` |
| Partner → PricingTier | 1 : N | optional | `pricingGrid?` |
| Onboarding → Partner/Shipper | **none** | ⚠️ | no FK exists — **DD-08** |
| Document → owner | polymorphic | — | 4 owner types today |

---

## 4. Lifecycle relationships

### 4.1 The Shipment ↔ Empty Return loop

This is the system's defining workflow. It is **bidirectional** and currently implemented by two Zustand stores importing each other through `shipmentBridge.ts`.

```mermaid
stateDiagram-v2
    direction LR

    [*] --> Pending : shipment created
    Pending --> MatchingPool : containerized (auto)
    MatchingPool --> Assigned : createCycle() forces status
    Assigned --> DriverAssigned
    DriverAssigned --> EnRoute
    EnRoute --> Arrived
    Arrived --> EmptyReturnSpawned : ER record auto-created
    Arrived --> Unloading
    Unloading --> PODSubmitted
    PODSubmitted --> Completed
    EmptyReturnSpawned --> Completed : cycle milestone 16 forces status
    Completed --> [*]
```

**Two edges bypass the linear ladder entirely** (BR-2.3): `createCycle` forces `→ Assigned`, and cycle completion forces `→ Completed`, skipping five intermediate states. Any server-side state machine must permit both or the cycle workflow breaks.

### 4.2 Empty Return cycle — one-way, no cancel, no undo

```mermaid
stateDiagram-v2
    [*] --> unloading : shipment reached Arrived
    unloading --> empty_ready : markEmptyReady (m3)
    empty_ready --> preparing : createCycle (m4)
    preparing --> ready : confirmCycle, all 16 checked (m7)
    ready --> in_progress : dispatchTruck (m8)
    in_progress --> in_progress : advanceMilestone
    in_progress --> completed : milestone >= 16
    completed --> [*] : spawns next record for nextFull
```

`markStandaloneRequired` sets an exception **without changing status** — it permanently removes the record from matching.

**Every guard above is enforced in a React component today, not in the store** (BR-4.1).

### 4.3 Container chain — the recurring loop

```
Container C ──delivered──► EmptyReturn ER-1 ──cycle CYC-1──► returned
                                │
                                └─ nextFull = Shipment S2 (consumed from pool)
                                       │
                                       └──delivered──► EmptyReturn ER-2 ──CYC-2──► …
```

Cycles join a chain only when **transporter AND location match** and the chain is not fully completed (BR-4.4). `seq` counts completed cycles too, so it climbs across the chain's whole life (BR-4.5).

---

## 5. Ownership and deletion semantics

| Parent | Child | On parent delete | Rationale |
|---|---|---|---|
| Partner | Vehicle, Driver, PricingTier, Contact | **Cascade** | No independent existence |
| Shipper | Contact | Cascade | — |
| Shipment | ShipmentEvent, Charge, DelayAttribution | Cascade | Facts about the shipment |
| Partner / Shipper | **Shipment** | **RESTRICT** | Financial history must survive |
| Partner / Shipper | **Document** | **Soft delete** | Compliance evidence is auditable |
| EmptyReturn | Cycle | RESTRICT | Cycles are audit records |
| Onboarding | Action, Comment | Cascade | — |
| Anything | **Finance records** | **NEVER** | Append-only ledger |

**Soft delete required on:** Shipper, Partner, Vehicle, Driver, Shipment, Document, Location. Everything financial is append-only and reversed by counter-entry, never deleted.

---

## 6. Identity notes

- Every id in the frontend today is a **display string** (`MSN-2026-8801`, `PTR-001`), not a UUID.
- Phase 1 uses `uuid()` primary keys throughout.
- Recommended: **UUID primary key + a separate human-readable `reference` column** with a real database sequence. This preserves the operator-facing identifiers users already know while fixing the collision-prone generators catalogued in `BUSINESS_RULES.md` §9.
- ⚠️ **Mock ID spaces are not consistent between files** (`SHP-102` is two different companies) — see `DOMAIN_MAP.md` §5.1 and **DD-11**. Do not treat them as foreign keys during seeding.

---

## 7. Legend

| Notation | Meaning |
|---|---|
| `\|\|--o{` | one-to-many, mandatory parent |
| `\|\|--o\|` | one-to-zero-or-one |
| `\|\|..o{` | **soft reference** — string id, no FK constraint |
| `}o--o{` | many-to-many |
| ⚠️ DD-nn | unresolved; see `DOMAIN_DECISIONS.md` |
